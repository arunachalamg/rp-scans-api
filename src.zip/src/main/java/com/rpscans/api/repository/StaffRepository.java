package com.rpscans.api.repository;

import com.rpscans.api.entity.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StaffRepository extends JpaRepository<Staff, Long> {
    boolean existsByStaffId(String staffId);
}
